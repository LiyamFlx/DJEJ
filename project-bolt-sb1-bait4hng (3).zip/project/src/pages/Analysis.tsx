import React from 'react';
import { AudioAnalyzer } from '../components/audio/AudioAnalyzer';
import { useAudioStore } from '../store/audioStore';
import { Card } from '../components/ui/Card';

const Analysis: React.FC = () => {
  const { audioData, error } = useAudioStore();

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Audio Analysis</h1>
      {error ? (
        <Card className="p-4 bg-red-500/20">
          <p className="text-white">{error.message}</p>
        </Card>
      ) : (
        <AudioAnalyzer audioData={audioData} />
      )}
    </div>
  );
};

export default Analysis;