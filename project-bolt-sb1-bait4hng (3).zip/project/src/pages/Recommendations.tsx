import React from 'react';
import { TrackRecommendationPanel } from '../components/recommendations/TrackRecommendationPanel';
import { useAudioStore } from '../store/audioStore';
import { useTrackRecommendations } from '../hooks/useTrackRecommendations';
import { Card } from '../components/ui/Card';

const Recommendations: React.FC = () => {
  const { audioData, metrics, error } = useAudioStore();
  const { recommendations, isLoading, error: recError } = useTrackRecommendations(
    audioData?.metrics ?? null,
    metrics
  );

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Track Recommendations</h1>
      {error ? (
        <Card className="p-4 bg-red-500/20">
          <p className="text-white">{error.message}</p>
        </Card>
      ) : (
        <TrackRecommendationPanel
          recommendations={recommendations}
          isLoading={isLoading}
          error={recError}
          onSelectTrack={(track) => console.log('Selected track:', track)}
        />
      )}
    </div>
  );
};

export default Recommendations;