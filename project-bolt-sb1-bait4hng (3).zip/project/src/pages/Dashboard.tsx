import React from 'react';
import { DJDashboard } from '../components/dj/DJDashboard';

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-white">Dashboard</h1>
      <DJDashboard />
    </div>
  );
};

export default Dashboard;