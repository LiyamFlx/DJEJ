import React from 'react';
import { 
  Mic, Square,
  Upload, Download, Play, FileAudio
} from 'lucide-react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';

interface ControlPanelProps {
  isRecording: boolean;
  onStartRecording: () => void;
  onStopRecording: () => void;
  onUpload: () => void;
  onExport: () => void;
  onAnalyze: () => void;
  disabled?: boolean;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  isRecording,
  onStartRecording,
  onStopRecording,
  onUpload,
  onExport,
  onAnalyze,
  disabled = false
}) => (
  <Card className="p-6">
    <div className="space-y-6">
      {/* Recording Controls */}
      <div className="grid grid-cols-2 gap-4">
        <Button
          variant="primary"
          size="lg"
          icon={isRecording ? Square : Mic}
          onClick={isRecording ? onStopRecording : onStartRecording}
          disabled={disabled}
        >
          {isRecording ? 'Stop Recording' : 'Start Recording'}
        </Button>

        <Button
          variant="primary"
          size="lg"
          icon={FileAudio}
          onClick={onAnalyze}
          disabled={disabled}
        >
          Analyze Audio
        </Button>
      </div>

      {/* Secondary Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Button
          variant="secondary"
          icon={Upload}
          onClick={onUpload}
          disabled={disabled}
        >
          Upload Audio
        </Button>
        <Button
          variant="secondary"
          icon={Download}
          onClick={onExport}
          disabled={disabled}
        >
          Export Data
        </Button>
      </div>
    </div>
  </Card>
);