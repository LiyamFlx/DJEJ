import React, { useEffect, useRef, useMemo } from 'react';
import { Card } from '../ui/Card';
import { AudioVisualizer } from '../../utils/visualization/visualizer';

interface FrequencyBarsProps {
  analyzerNode: AnalyserNode | null;
  isActive: boolean;
  className?: string;
}

export const FrequencyBars: React.FC<FrequencyBarsProps> = React.memo(({
  analyzerNode,
  isActive,
  className = ''
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const visualizerRef = useRef<AudioVisualizer | null>(null);

  // Create visualizer instance
  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas && !visualizerRef.current) {
      visualizerRef.current = new AudioVisualizer(canvas);
    }
    
    return () => {
      if (visualizerRef.current) {
        visualizerRef.current.stop();
      }
    };
  }, []);

  // Handle visualization
  useEffect(() => {
    if (!analyzerNode || !isActive || !visualizerRef.current) {
      visualizerRef.current?.stop();
      return;
    }

    visualizerRef.current.drawFrequencyBars(analyzerNode, {
      barWidth: 3,
      barGap: 1,
      minHeight: 4,
      maxHeight: visualizerRef.current.height,
      minDecibels: -90,
      maxDecibels: -10
    });

    return () => {
      visualizerRef.current?.stop();
    };
  }, [analyzerNode, isActive]);

  return (
    <Card className={`p-4 ${className}`}>
      <h3 className="text-lg font-semibold text-white mb-4">Frequency Analysis</h3>
      <div className="relative w-full h-64 bg-black/20 rounded-lg overflow-hidden">
        <canvas
          ref={canvasRef}
          className="w-full h-full block"
        />
        {!isActive && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40">
            <p className="text-white/60">Recording paused</p>
          </div>
        )}
      </div>
    </Card>
  );
});

FrequencyBars.displayName = 'FrequencyBars';