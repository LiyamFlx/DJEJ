// Update the recommendations prop to have a default value
export const TrackSuggestions: React.FC<TrackSuggestionsProps> = ({
  recommendations = [], // Add default empty array
}) => {
  // Component logic...
};