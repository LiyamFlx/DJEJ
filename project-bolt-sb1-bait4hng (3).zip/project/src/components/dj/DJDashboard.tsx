import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { ControlPanel } from '../controls/ControlPanel';
import { VisualizationPanel } from '../visualizations/VisualizationPanel';
import { TrackRecommendationPanel } from '../recommendations/TrackRecommendationPanel';
import { AnalysisProgress } from '../analysis/AnalysisProgress';
import { AnalysisResults } from '../analysis/AnalysisResults';
import { CrowdSentimentIndicator } from '../engagement/CrowdSentimentIndicator';
import { EngagementHeatmap } from '../engagement/EngagementHeatmap';
import { useAudioProcessor } from '../../hooks/useAudioProcessor';
import { useEngagementVisualization } from '../../hooks/useEngagementVisualization';
import { useTrackRecommendations } from '../../hooks/useTrackRecommendations';
import { useRecordingAnalysis } from '../../hooks/useRecordingAnalysis';
import { ExportDialog } from '../export/ExportDialog';
import { Card } from '../ui/Card';

export const DJDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);
  
  const {
    audioData,
    isRecording,
    isProcessing,
    startRecording,
    stopRecording,
    error
  } = useAudioProcessor({
    sensitivity: 50,
    noiseThreshold: 30,
    updateInterval: 100
  });

  const { sentiment, trend, history } = useEngagementVisualization(audioData?.metrics ?? null);
  const { recommendations, currentTrack, isLoading, error: recError, playTrack } = useTrackRecommendations(
    audioData?.metrics ?? null,
    history,
    128 // Default BPM, should be updated based on actual audio analysis
  );
  const { state: analysisState, results: analysisResults, analyzeRecording } = useRecordingAnalysis();

  const handleStartRecording = useCallback(async () => {
    setIsAnalyzing(true);
    await startRecording();
    setIsAnalyzing(false);
  }, [startRecording]);

  const handleTrackSelect = useCallback((track) => {
    playTrack(track);
  }, [playTrack]);

  const handleStopRecording = useCallback(async () => {
    await stopRecording();
    if (audioData) {
      await analyzeRecording(audioData);
      setShowExportDialog(true);
    }
  }, [stopRecording, audioData, analyzeRecording]);

  const handleNavigate = (direction: 'home' | 'prev' | 'next') => {
    switch (direction) {
      case 'home':
        navigate('/');
        break;
      case 'prev':
        navigate(-1);
        break;
      case 'next':
        navigate(1);
        break;
    }
  };

  const handleFileUpload = useCallback(() => {
    // Implement file upload logic
    console.log('File upload clicked');
  }, []);

  const handleExport = useCallback(() => {
    // Implement export logic
    console.log('Export clicked');
  }, []);

  const handleAnalyze = useCallback(() => {
    if (audioData) {
      analyzeRecording(audioData);
      setShowExportDialog(true);
    }
  }, [audioData, analyzeRecording]);

  // Prevent unnecessary re-renders
  const memoizedNavigate = useCallback((direction: 'home' | 'prev' | 'next') => {
    switch (direction) {
      case 'home':
        navigate('/');
        break;
      case 'prev':
        navigate(-1);
        break;
      case 'next':
        navigate(1);
        break;
    }
  }, [navigate]);

  if (error) {
    return (
      <Card className="p-4 bg-red-500/20">
        <p className="text-white">{error.message}</p>
      </Card>
    );
  }

  return (
    <>
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
      <ControlPanel
        isRecording={isRecording}
        onStartRecording={handleStartRecording}
        onStopRecording={handleStopRecording}
        onNavigate={memoizedNavigate}
        onUpload={handleFileUpload}
        onExport={handleExport}
        onAnalyze={handleAnalyze}
        disabled={isProcessing || isAnalyzing}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <VisualizationPanel
            audioData={audioData}
            isActive={isRecording && !isProcessing}
          />
          
          {analysisState.isAnalyzing ? (
            <AnalysisProgress progress={analysisState.progress} />
          ) : analysisResults && (
            <AnalysisResults
              features={analysisResults.features}
              metrics={analysisResults.metrics}
              insights={analysisResults.insights}
            />
          )}

          <EngagementHeatmap history={history} />
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          <CrowdSentimentIndicator
            sentiment={sentiment ?? 50}
            trend={trend}
          />
          <TrackRecommendationPanel
            recommendations={recommendations}
            currentTrack={currentTrack}
            isLoading={isLoading}
            error={recError}
            currentTrack={currentTrack}
            onSelectTrack={handleTrackSelect}
          />
        </div>
      </div>
    </div>
    <ExportDialog
      isOpen={showExportDialog}
      onClose={() => setShowExportDialog(false)}
      audioData={audioData}
      analysisResults={analysisResults}
    />
    </>
  );
};