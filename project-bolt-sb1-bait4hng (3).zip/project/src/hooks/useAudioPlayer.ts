import { useState, useCallback, useRef, useEffect } from 'react';
import { useAudioCache } from './useAudioCache';

export const useAudioPlayer = () => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyzerRef = useRef<AnalyserNode | null>(null);
  const { cache } = useAudioCache();

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrackId, setCurrentTrackId] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new AudioContext();
      analyzerRef.current = audioContextRef.current.createAnalyser();
      analyzerRef.current.fftSize = 2048;
    }

    return () => {
      sourceRef.current?.stop();
      audioContextRef.current?.close();
    };
  }, []);

  const play = useCallback(async (url: string, trackId: string) => {
    if (!audioContextRef.current || !analyzerRef.current) return;

    // Validate URL and audio format
    if (!url || !url.startsWith('http')) {
      throw new Error('Invalid audio URL');
    }

    // Check if URL points to a supported audio format
    const supportedFormats = ['.mp3', '.wav', '.ogg', '.m4a'];
    if (!supportedFormats.some(format => url.toLowerCase().endsWith(format))) {
      throw new Error('Unsupported audio format');
    }

    setError(null);

    if (currentTrackId === trackId && isPlaying) {
      audioRef.current?.pause();
      sourceRef.current?.stop();
      setIsPlaying(false);
      return;
    }

    try {
      // Stop any currently playing source
      sourceRef.current?.stop();
      
      // Pre-fetch audio to validate it loads
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Failed to load audio file');
      }
      const contentType = response.headers.get('content-type');
      if (!contentType?.includes('audio/')) {
        throw new Error('Invalid audio content type');
      }

      // Create new audio element with proper settings
      const audio = new Audio();
      audio.crossOrigin = 'anonymous';
      audio.src = url;

      const buffer = await response.arrayBuffer();
      const audioBuffer = await audioContextRef.current.decodeAudioData(buffer);

      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(analyzerRef.current);
      analyzerRef.current.connect(audioContextRef.current.destination);
      
      sourceRef.current = source;
      source.start(0);
      setCurrentTrackId(trackId);
      setIsPlaying(true);

      source.onended = () => {
        sourceRef.current = null;
        setIsPlaying(false);
        setCurrentTrackId(null);
        setProgress(0);
        setError(null);
      };

    } catch (err) {
      console.error('Failed to play audio:', err);
      setError(err instanceof Error ? err : new Error('Failed to play audio'));
      setIsPlaying(false);
      setCurrentTrackId(null);
      sourceRef.current = null;
    }
  }, [currentTrackId, isPlaying, cache]);

  const stop = useCallback(() => {
      setError(null);
    sourceRef.current?.stop();
    sourceRef.current = null;
    setIsPlaying(false);
    setCurrentTrackId(null);
    setProgress(0);
    setError(null);
  }, []);

  return {
    play,
    stop,
    isPlaying,
    currentTrackId,
    progress,
    error,
    analyzerNode: analyzerRef.current
  };
};