import { AudioData, AudioMetrics } from '../../../types/audio';
import { performance } from 'perf_hooks';

const CHUNK_SIZE = 1024;
const SAMPLE_RATE = 44100;

export class AudioAnalyzer {
  private readonly fftSize: number;
  private readonly smoothingTimeConstant: number;

  constructor(config = { fftSize: 2048, smoothingTimeConstant: 0.8 }) {
    this.fftSize = config.fftSize;
    this.smoothingTimeConstant = config.smoothingTimeConstant;
  }

  async analyze(audioData: AudioData): Promise<AudioMetrics> {
    const startTime = performance.now();
    
    try {
      const chunks = this.splitIntoChunks(audioData.frequency);
      const results = await Promise.all(chunks.map(chunk => this.processChunk(chunk)));
      const metrics = this.aggregateResults(results);
      
      console.debug(`Analysis completed in ${performance.now() - startTime}ms`);
      return metrics;
    } catch (error) {
      console.error('Analysis failed:', error);
      throw error;
    }
  }

  private splitIntoChunks(data: Float32Array): Float32Array[] {
    const chunks: Float32Array[] = [];
    for (let i = 0; i < data.length; i += CHUNK_SIZE) {
      chunks.push(data.slice(i, i + CHUNK_SIZE));
    }
    return chunks;
  }

  private async processChunk(chunk: Float32Array): Promise<AudioMetrics> {
    const physical = this.calculatePhysicalMetrics(chunk);
    const emotional = this.calculateEmotionalMetrics(chunk);
    const mental = this.calculateMentalMetrics(chunk);
    const spiritual = this.calculateSpiritualMetrics(chunk);

    return { physical, emotional, mental, spiritual };
  }

  private calculatePhysicalMetrics(data: Float32Array): number {
    const rms = Math.sqrt(data.reduce((acc, val) => acc + val * val, 0) / data.length);
    return Math.min(rms * 100, 100);
  }

  private calculateEmotionalMetrics(data: Float32Array): number {
    // Enhanced emotional analysis using multiple features
    const spectralCentroid = this.calculateSpectralCentroid(data);
    const spectralFlux = this.calculateSpectralFlux(data);
    const spectralRolloff = this.calculateSpectralRolloff(data);
    
    // Weight and combine features for better emotional detection
    const emotionalScore = (
      spectralCentroid * 0.4 +
      spectralFlux * 0.3 +
      spectralRolloff * 0.3
    );
    
    return Math.min(emotionalScore * 100, 100);
  }

  private calculateMentalMetrics(data: Float32Array): number {
    const complexity = this.calculateSpectralComplexity(data);
    return Math.min(complexity * 100, 100);
  }

  private calculateSpiritualMetrics(data: Float32Array): number {
    const harmonicity = this.calculateHarmonicity(data);
    return Math.min(harmonicity * 100, 100);
  }

  private calculateSpectralCentroid(data: Float32Array): number {
    let numerator = 0;
    let denominator = 0;
    
    data.forEach((magnitude, i) => {
      numerator += magnitude * i;
      denominator += magnitude;
    });
    
    return denominator === 0 ? 0 : numerator / denominator;
  }

  private calculateSpectralComplexity(data: Float32Array): number {
    const mean = data.reduce((acc, val) => acc + val, 0) / data.length;
    const variance = data.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / data.length;
    return Math.sqrt(variance);
  }

  private calculateHarmonicity(data: Float32Array): number {
    const fundamentalFreq = this.findFundamentalFrequency(data);
    let harmonicContent = 0;
    
    for (let i = 2; i <= 8; i++) {
      const harmonicIdx = fundamentalFreq * i;
      if (harmonicIdx < data.length) {
        harmonicContent += Math.abs(data[harmonicIdx]);
      }
    }
    
    return harmonicContent / 8;
  }

  private findFundamentalFrequency(data: Float32Array): number {
    let maxIndex = 0;
    let maxValue = -Infinity;
    
    for (let i = 0; i < data.length / 4; i++) {
      if (data[i] > maxValue) {
        maxValue = data[i];
        maxIndex = i;
      }
    }
    
    return maxIndex;
  }

  private calculateSpectralFlux(data: Float32Array): number {
    let flux = 0;
    for (let i = 1; i < data.length; i++) {
      flux += Math.pow(data[i] - data[i - 1], 2);
    }
    return Math.sqrt(flux) / data.length;
  }

  private calculateSpectralRolloff(data: Float32Array): number {
    const totalEnergy = data.reduce((sum, val) => sum + Math.abs(val), 0);
    let cumulativeEnergy = 0;
    
    for (let i = 0; i < data.length; i++) {
      cumulativeEnergy += Math.abs(data[i]);
      if (cumulativeEnergy >= totalEnergy * 0.85) {
        return i / data.length;
      }
    }
    return 1;
  }

  private aggregateResults(results: AudioMetrics[]): AudioMetrics {
    const aggregate = results.reduce((acc, curr) => ({
      physical: acc.physical + curr.physical,
      emotional: acc.emotional + curr.emotional,
      mental: acc.mental + curr.mental,
      spiritual: acc.spiritual + curr.spiritual
    }), { physical: 0, emotional: 0, mental: 0, spiritual: 0 });

    return {
      physical: aggregate.physical / results.length,
      emotional: aggregate.emotional / results.length,
      mental: aggregate.mental / results.length,
      spiritual: aggregate.spiritual / results.length
    };
  }
}