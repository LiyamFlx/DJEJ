import { AudioData } from '../../types/audio';

type ExportFormat = 'json' | 'csv' | 'pdf';

export const exportData = (data: AudioData, format: ExportFormat = 'json') => {
  switch (format) {
    case 'json':
      exportJSON(data);
      break;
    case 'csv':
      exportCSV(data);
      break;
    case 'pdf':
      exportPDF(data);
      break;
  }
};

const exportJSON = (data: AudioData) => {
  const jsonString = JSON.stringify(data, null, 2);
  downloadFile(jsonString, 'audio-analysis.json', 'application/json');
};

const exportCSV = (data: AudioData) => {
  const metrics = data.metrics;
  const csvContent = Object.entries(metrics)
    .map(([key, value]) => `${key},${value}`)
    .join('\n');
  
  downloadFile(csvContent, 'audio-analysis.csv', 'text/csv');
};

const exportPDF = (data: AudioData) => {
  // PDF export would typically use a library like jsPDF
  console.log('PDF export not implemented yet');
};

const downloadFile = (content: string, filename: string, type: string) => {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};