export class AudioVisualizer {
  private readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  public width: number;
  public height: number;
  private animationFrame: number | null = null;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Failed to get canvas context');
    this.ctx = ctx;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    this.width = rect.width;
    this.height = rect.height;
    
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    this.ctx.scale(dpr, dpr);
  }

  drawFrequencyBars(analyzerNode: AnalyserNode, options = {
    barWidth: 2,
    barGap: 1,
    minHeight: 2,
    maxHeight: this.height,
    minDecibels: -90,
    maxDecibels: -10
  }) {
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
    }

    const frequencyData = new Uint8Array(analyzerNode.frequencyBinCount);
    
    const draw = () => {
      this.animationFrame = requestAnimationFrame(draw);
      analyzerNode.getByteFrequencyData(frequencyData);

      this.ctx.clearRect(0, 0, this.width, this.height);

      const barCount = Math.floor(this.width / (options.barWidth + options.barGap));
      const dataStep = Math.floor(frequencyData.length / barCount);

      for (let i = 0; i < barCount; i++) {
        const value = frequencyData[i * dataStep];
        const percent = value / 255;
        const barHeight = Math.max(
          options.minHeight,
          Math.min(options.maxHeight * percent, options.maxHeight)
        );
        
        const hue = (i / barCount) * 360;
        this.ctx.fillStyle = `hsla(${hue}, 80%, 60%, 0.8)`;

        this.ctx.fillRect(
          i * (options.barWidth + options.barGap),
          this.height - barHeight,
          options.barWidth,
          barHeight
        );
      }
    };
    
    draw();
  }

  stop() {
    if (this.animationFrame) {
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
    }
  }

  clear() {
    this.ctx.clearRect(0, 0, this.width, this.height);
  }
}