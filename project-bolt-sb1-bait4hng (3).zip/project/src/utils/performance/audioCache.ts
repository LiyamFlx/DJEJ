interface CacheEntry {
  buffer: AudioBuffer;
  timestamp: number;
}

export class AudioCache {
  private cache: Map<string, CacheEntry>;
  private readonly maxSize: number;
  private readonly ttl: number;

  constructor(maxSize = 20, ttl = 3600000) {
    this.cache = new Map();
    this.maxSize = maxSize;
    this.ttl = ttl;
  }

  async get(url: string): Promise<AudioBuffer | null> {
    const entry = this.cache.get(url);
    
    if (!entry) return null;
    
    if (Date.now() - entry.timestamp > this.ttl) {
      this.cache.delete(url);
      return null;
    }
    
    return entry.buffer;
  }

  async set(url: string, buffer: AudioBuffer): Promise<void> {
    if (this.cache.size >= this.maxSize) {
      const oldestKey = Array.from(this.cache.entries())
        .sort(([, a], [, b]) => a.timestamp - b.timestamp)[0][0];
      this.cache.delete(oldestKey);
    }

    this.cache.set(url, {
      buffer,
      timestamp: Date.now()
    });
  }

  clear(): void {
    this.cache.clear();
  }

  async preload(urls: string[]): Promise<void> {
    const audioContext = new AudioContext();
    
    await Promise.all(urls.map(async url => {
      if (await this.get(url)) return;
      
      try {
        const response = await fetch(url);
        const arrayBuffer = await response.arrayBuffer();
        const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
        await this.set(url, audioBuffer);
      } catch (error) {
        console.error(`Failed to preload audio: ${url}`, error);
      }
    }));
  }
}